import streamlit as st
import pandas as pd
import plotly.express as px
from sklearn.cluster import KMeans
from sklearn.linear_model import LinearRegression
import numpy as np
st.set_page_config(page_title="Sales Analysis", layout="wide")
st.title("AI-Powered Sales Analysis Dashboard")
uploaded_file=st.file_uploader("sales.txt",type=["csv"])
if uploaded_file:
    df=pd.read_csv(uploaded_file)
    st.subheader("Sales Data Overview")
    st.dataframe(df.head())
# --- Date Processing ---
    df['Date']=pd.to_datetime(df["Date"])
    df['Month']=df['Date'].dt.to_period('M').astype(str)
# --- Sales by Month ---
    monthly_sales=df.groupby('Month')['Sales'].sum().reset_index()
    fig=px.line(monthly_sales,x='Month',y='Sales',title='Monthly Sales Trend')
    st.plotly_chart(fig,use_container_width=True)
# --- Sales Forecast(Linear Regression)---
    monthly_sales['Month_Num']=np.arange(len(monthly_sales))
    x= monthly_sales[['Month_Num']]
    y= monthly_sales['Sales']
    model=LinearRegression()
    model.fit(x,y)  
    future_months=3
    future_X=np.arange(len(monthly_sales),len(monthly_sales)+future_months).reshape(-1,1)
    predictions=model.predict(future_X)
    st.subheader("Sales Forecast for Next 3 Months")
    st.write(predictions)
# --- Clustering (KMeans) ---
    st.subheader("Customer Segmentation (KMeans Clustering)")
    if 'CustomerID' in df.columns:
        cust_df=df.groupby('CustomerID')['Sales'].sum().reset_index()
        kmeans=KMeans(n_clusters=3,random_state=42)
        cust_df['Segment']=kmeans.fit_predict(cust_df[['Sales']])
        st.dataframe(cust_df.head())
        fig2=px.scatter(cust_df,x='CustomerID',y='Sales',color='Segment',title='Customer Segmentation')
        st.plotly_chart(fig2,use_container_width=True)

#--- AI Recommendations ---
    st.subheader("AI-Driven Sales Recommendations")
    best_month=monthly_sales.loc[monthly_sales['Sales'].idxmax(),'Month']
    st.success(f"Focus Promotions like in **{best_month}**, which had the highest sales!")