import streamlit as st
import pandas as pd
import numpy as np
import os

# 1. Page Configuration
st.set_page_config(
    page_title="Diabetes Risk Dashboard",
    page_icon="🩺",
    layout="wide"
)

# 2. Hardcoded File Path (Reads directly from your project directory)
DATASET_PATH = "diabetes_risk_dataset.csv"

# 3. Secure Data Loading & Cleaning Function
@st.cache_data # Keeps data in memory so the app stays fast
def load_and_clean_data(path):
    if not os.path.exists(path):
        return None
        
    df = pd.read_csv(path)
    
    # Clean Missing Values Automatically
    # Drop rows missing crucial targets
    if 'diabetes_risk_category' in df.columns:
        df = df.dropna(subset=['diabetes_risk_category'])
        
    # Fill numerical columns with median
    num_cols = df.select_dtypes(include=[np.number]).columns
    for col in num_cols:
        df[col] = df[col].fillna(df[col].median())
        
    # Fill text columns with most frequent value (mode)
    text_cols = df.select_dtypes(include=['object']).columns
    for col in text_cols:
        if not df[col].empty:
            df[col] = df[col].fillna(df[col].mode()[0])
            
    return df

# Load the dataset directly
df_clean = load_and_clean_data(DATASET_PATH)

# 4. Sidebar Navigation
# Place this right before your sidebar navigation radio buttons
st.sidebar.image("DiabetesLogo.png", use_container_width=True)
st.sidebar.title("Navigation")
app_mode = st.sidebar.radio("Go to", ["Data Analytics Dashboard", "Patient Risk Predictor"])

# ==================== MAIN LOGIC ====================
if df_clean is None:
    st.error(f"❌ Error: The file `{DATASET_PATH}` was not found in your VS Code folder directory.")
    st.info("💡 Please make sure your dataset is named exactly `diabetes_prediction.csv` and sits in the same directory as your app file.")
else:
    # ==================== MODE: DATA ANALYTICS ====================
    # Custom Styled Diabetes Awareness Ticker Banner
    st.markdown(
    """
    <marquee behavior="scroll" direction="left" scrollamount="5" loop="infinite"
             style="color: #0D47A1; font-weight: 600; font-size: 15px; 
                    background-color: #E3F2FD; padding: 10px; border-radius: 6px;
                    border: 1px solid #BBDEFB; font-family: sans-serif;">
        📘 <b>Diabetes</b> is a chronic medical condition that affects how your body turns food into energy. Most of the food you eat is broken down into sugar (glucose) and released into your bloodstream. When your blood sugar goes up, it signals your pancreas to release insulin. Insulin acts like a key to let blood sugar into your body’s cells for use as energy.If you have Diabetes. Then You start the following routine ->
        🏃‍♂️ <b>Physical Activity:</b> Just 30 minutes of moderate exercise 5 days a week can drastically improve insulin sensitivity. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        🥗 <b>Healthy Eating:</b> Swapping processed sugars for high-fiber foods helps prevent blood glucose spikes. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        🩺 <b>Early Detection:</b> Type 2 diabetes often develops silently; regular fasting glucose and HbA1c tests save lives. &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        💧 <b>Stay Hydrated:</b> Choosing water over sugary drinks decreases risk levels and supports kidney function.
    </marquee>
    """, 
    unsafe_allow_html=True
    )
    st.write("") # Adds clean spacing below the banner


    if app_mode == "Data Analytics Dashboard":
        st.title("Diabetes Prediction & Risk Assessment Dashboard")
        st.success(f"✅ Successfully loaded and auto-cleaned `{DATASET_PATH}` directly from local directory!")
        
        # Stat cards
        st.subheader("Dataset Summary Metrics")
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Total Sample Size", f"{len(df_clean)} patients")
        m2.metric("Average Patient Age", f"{round(df_clean['age'].mean(), 1)} years")
        m3.metric("Average BMI Baseline", f"{round(df_clean['bmi'].mean(), 1)}")
        m4.metric("Avg Glucose Level", f"{round(df_clean['fasting_glucose_level'].mean(), 1)} mg/dL")
        
        # 1.5 Custom CSS to Reduce Stat Card Padding and Font Size
        st.markdown("""
        <style>
        /* target the inner box of the metric widget */
        [data-testid="stMetricValue"] {
        font-size: 24px !important;  /* Shrunk text from default 40px */
        font-weight: 600;
        }
        [data-testid="stMetricLabel"] {
        font-size: 14px !important;  /* Shrunk label font size */
        }
        [data-testid="stMetric"] {
        padding: 5px 10px !important; /* Shrunk padding inside the card */
        }
        </style>
        """, unsafe_allow_html=True)

        # Raw Data Sample expander
        with st.expander("📂 View Cleaned Dataset Preview"):
            st.dataframe(df_clean)
            #st.subheader("Filtered Student Records")
            #st.dataframe(df)
    
        # Charts section
        st.subheader("Key Health Correlations & Demographics")
        
        # New Row: Gender Distribution Pie Chart
        row1_col1, row1_col2 = st.columns([1, 1])
        
        with row1_col1:
            st.markdown("##### Gender-Wise Patient Distribution")
            if 'gender' in df_clean.columns:
                # 1. Count patients per gender group
                gender_counts = df_clean['gender'].value_counts().reset_index()
                gender_counts.columns = ['Gender', 'Patient Count']
                
                # 2. Generate interactive Plotly Pie Chart
                import plotly.express as px
                fig = px.pie(
                    gender_counts, 
                    values='Patient Count', 
                    names='Gender',
                    color_discrete_sequence=px.colors.qualitative.Pastel
                )
                # Optimize chart sizing
                fig.update_layout(margin=dict(t=20, b=20, l=20, r=20), height=350)
                
                # 3. Render chart in Streamlit
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("Required 'gender' column missing for this plot.")
                
        with row1_col2:
            st.markdown("##### Average BMI Across Risk Categories")
            if 'diabetes_risk_category' in df_clean.columns and 'bmi' in df_clean.columns:
                bmi_summary = df_clean.groupby('diabetes_risk_category')['bmi'].mean()
                st.bar_chart(bmi_summary)
            else:
                st.info("Required columns missing for this plot.")
        st.markdown("---")
        # Charts section
        chart_col1, chart_col2 = st.columns(2)
        
        with chart_col1:
            st.markdown("##### Sugar Intake vs HbA1c Levels")
            if 'sugar_intake_grams_per_day' in df_clean.columns and 'HbA1c_level' in df_clean.columns:
                st.scatter_chart(data=df_clean, x='sugar_intake_grams_per_day', y='HbA1c_level')
            else:
                st.info("Required columns missing for this plot.")
                
        st.markdown("---")

        st.markdown("##### 📈 Cardiovascular Trends Over Age Brackets")
        if all(col in df_clean.columns for col in ['age', 'blood_pressure', 'cholesterol_level']):
            # 1. Group by age and calculate the mean for medical metrics
            age_trends = df_clean.groupby('age')[['blood_pressure', 'cholesterol_level']].mean().reset_index()
            # 2. Generate the interactive multi-line chart using Plotly
            import plotly.express as px
            fig_line = px.line(
                age_trends, 
                x='age', 
                y=['blood_pressure', 'cholesterol_level'],
                labels={'value': 'Measurement Value', 'variable': 'Metric Type'},
                color_discrete_sequence=['#E84A5F', '#4A90E2'] # Red for Blood Pressure, Blue for Cholesterol
            )
    
            # 3. Clean layout styling
            fig_line.update_layout(
                margin=dict(t=20, b=20, l=20, r=20), 
                height=350,
                xaxis_title="Patient Age (Years)",
                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
           )
    
            # 4. Render chart in Streamlit
            st.plotly_chart(fig_line, use_container_width=True)
        else:
            st.info("Missing 'age', 'blood_pressure', or 'cholesterol_level' columns in your data file.")

        st.markdown("---")


        # --- ROW 3: Lifestyle & Metabolic Trends ---
        row3_col1, row3_col2 = st.columns(2)

        with row3_col1:
            st.markdown("##### 🧠 Stress Level vs. Sleep Hours")
            if 'stress_level' in df_clean.columns and 'sleep_hours' in df_clean.columns:
                # Group data to see the trend clearly without a messy scatter plot
                stress_sleep = df_clean.groupby(['stress_level', 'sleep_hours']).size().reset_index(name='Patient Count')
                fig_stress = px.scatter(
                    stress_sleep, 
                    x='sleep_hours', 
                    y='stress_level', 
                    size='Patient Count',
                    color='stress_level',
                    color_continuous_scale=px.colors.sequential.Viridis
                )
                fig_stress.update_layout(margin=dict(t=20, b=20, l=20, r=20), height=300)
                st.plotly_chart(fig_stress, use_container_width=True)
            else:
                st.info("Missing stress level or sleep hours columns.")

        with row3_col2:
            st.markdown("##### 🧪 Insulin level vs. Triglycerides Trend")
            if 'insulin_level' in df_clean.columns and 'triglycerides_level' in df_clean.columns:
                # Sort data for a clean continuous trend visualization
                df_sorted = df_clean.sort_values(by='insulin_level')
                fig_insulin = px.line(
                    df_sorted, 
                    x='insulin_level', 
                    y='triglycerides_level',
                    color_discrete_sequence=['#E84A5F']
                )
                fig_insulin.update_layout(margin=dict(t=20, b=20, l=20, r=20), height=300)
                st.plotly_chart(fig_insulin, use_container_width=True)
            else:
                st.info("Missing insulin or triglycerides columns.")

        st.markdown("---")
        st.markdown("##### 🩸 Fasting Glucose Level Distribution")
        if 'fasting_glucose_level' in df_clean.columns:
            # 1. Generate the interactive histogram using Plotly
            fig_glucose = px.histogram(df_clean, 
                x='fasting_glucose_level',
                nbins=30,                     # Splits data into 30 balanced blood sugar blocks
                color_discrete_sequence=['#4A90E2'] # Clean medical blue color
            )
    
            # 2. Tighten up the chart margins and add axis labels
            fig_glucose.update_layout(
                margin=dict(t=20, b=20, l=20, r=20), 
                height=320, 
                xaxis_title="Fasting Glucose Range (mg/dL)",
                yaxis_title="Number of Patients"
            )
            # 3. Render the interactive chart inside your app
            st.plotly_chart(fig_glucose, use_container_width=True)
        else:
            st.info("The column 'fasting_glucose_level' was not found in your dataset file.")
        
        st.markdown("---")
         
        st.markdown("##### 📈 Dynamic Population Health Trends Across Ages")
        # Instead of cluttering your dashboard screen with six different line charts, this compact approach wraps everything into a single, clean visual area. The chart redraws itself instantly whenever a user clicks a new dropdown option.
        # 1. Define the available metrics from your dataset columns
        metric_options = {
            "Blood Pressure": "blood_pressure",
            "Cholesterol Level": "cholesterol_level",
            "Insulin Level": "insulin_level",
            "Triglycerides Level": "triglycerides_level",
            "Fasting Glucose Level": "fasting_glucose_level",
            "HbA1c Level": "HbA1c_level"
        }
            
        # 2. Render the interactive dropdown selector in your app interface
        selected_label = st.selectbox(
            "Select a health metric to analyze over time:", 
            options=list(metric_options.keys())
        )
        selected_column = metric_options[selected_label]
        # 3. Verify columns exist, group by age, and calculate the mean average trend
        if 'age' in df_clean.columns and selected_column in df_clean.columns:
    
            # Grouping ensures a smooth line from the youngest to the oldest patient
            dynamic_trends = df_clean.groupby('age')[selected_column].mean().reset_index()
    
            # 4. Generate the updating Plotly Line Chart
            import plotly.express as px
            fig_dynamic = px.line(
                dynamic_trends, 
                x='age', 
                y=selected_column,
                color_discrete_sequence=['#4A90E2'] # Clean medical blue
            )
            # 5. Optimize margins and axis labels dynamically
            fig_dynamic.update_layout(
                margin=dict(t=10, b=20, l=20, r=20), 
                height=350,
                xaxis_title="Patient Age (Years)",
                yaxis_title=f"Average {selected_label}"
            )
    
            # 6. Render the interactive plot in Streamlit
            st.plotly_chart(fig_dynamic, use_container_width=True)
        else:
            st.info("Ensure the selected metric column is properly formatted in your CSV file.")



    # ==================== MODE: RISK PREDICTOR ====================
    elif app_mode == "Patient Risk Predictor":
        st.title("🩺 Diabetes Patient Risk Predictor")
        st.write("Enter the patient's metrics to assess risk benchmarks based on dataset averages.")
        
        col1, col2 = st.columns(2)
        with col1:
            age = st.slider("Age", int(df_clean['age'].min()), int(df_clean['age'].max()), int(df_clean['age'].mean()))
            bmi = st.slider("BMI", float(df_clean['bmi'].min()), float(df_clean['bmi'].max()), float(df_clean['bmi'].mean()), step=0.1)
            glucose = st.slider("Fasting Glucose Level", int(df_clean['fasting_glucose_level'].min()), int(df_clean['fasting_glucose_level'].max()), int(df_clean['fasting_glucose_level'].mean()))
            
        with col2:
            hba1c = st.slider("HbA1c Level (%)", float(df_clean['HbA1c_level'].min()), float(df_clean['HbA1c_level'].max()), float(df_clean['HbA1c_level'].mean()), step=0.1)
            sugar = st.slider("Sugar Intake (g/day)", int(df_clean['sugar_intake_grams_per_day'].min()), int(df_clean['sugar_intake_grams_per_day'].max()), int(df_clean['sugar_intake_grams_per_day'].mean()))
            family_hist = st.selectbox("Family History?", list(df_clean['family_history_diabetes'].unique()))

        st.markdown("---")
        
        if st.button("Calculate Diabetes Risk Profile", type="primary"):
            # Simple rule logic using dataset baseline boundaries
            avg_glucose = df_clean['fasting_glucose_level'].mean()
            avg_hba1c = df_clean['HbA1c_level'].mean()
            
            if glucose > avg_glucose * 1.2 or hba1c > avg_hba1c * 1.2:
                st.error("🔴 **High Risk Profile**: Patient metrics sit well above the dataset baseline averages. Clinical screening recommended.")
            elif glucose > avg_glucose or hba1c > avg_hba1c:
                st.warning("🟡 **Moderate Risk Profile**: Patient metrics are elevated compared to the average population baseline.")
            else:
                st.success("🟢 **Low Risk Profile**: Patient health parameters match the healthy sample parameters perfectly.")
