# import streamlit as st
# import pandas as pd
# import numpy as np

# st.title("Student Data Analysis Dashboard")

# # 1. File Uploader (Accepts CSV or Excel)
# uploaded_file = st.file_uploader("Upload your student dataset", type=["csv", "xlsx"])

# if uploaded_file is not None:
#     # Load the data based on file type
#     if uploaded_file.name.endswith('.csv'):
#         df = pd.read_csv(uploaded_file)
#     else:
#         df = pd.read_excel(uploaded_file)
    
#     # Preview the data
#     st.subheader("Dataset Preview")
#     st.dataframe(df.head())
    
#     # 2. Let the user select the Gender column (in case it is named differently)
#     column_names = df.columns.tolist()
    
#     # Auto-select a column if it has 'gender' in its name
#     default_index = 0
#     for i, col in enumerate(column_names):
#         if 'gender' in col.lower():
#             default_index = i
#             break
            
#     gender_column = st.selectbox("Select the Gender column:", column_names, index=default_index)
    
#     # 3. Calculate and display the counts
#     if gender_column:
#         # Count the occurrences of each gender
#         gender_counts = df[gender_column].value_counts()
        
#         # Display the text counts
#         st.subheader("Gender Counts Summary")
#         st.write(gender_counts)
        
#         # 4. Generate the Bar Chart
#         st.subheader("Gender Distribution Chart")
#         st.bar_chart(gender_counts)
        
# else:
#     st.info("Please upload a CSV or Excel file to see the visualization.")

# # Mock Data generation if no file is uploaded yet
# if uploaded_file is None:
#     #st.sidebar.warning("Using sample data. Upload your file to update.")
#     data = {
#         'Gender': ['Male', 'Female', 'Female', 'Male', 'Female', 'Male', 'Female', 'Female', 'Male', 'Female'] * 5,
#         'Age': np.random.randint(18, 23, 50),
#         'Attendance_Rate': np.random.randint(60, 100, 50),
#         'Final_Grade': np.random.randint(50, 100, 50),
#         'Major': ['CS', 'Math', 'CS', 'Business', 'Math', 'Business', 'CS', 'Math', 'Business', 'CS'] * 5
#     }
#     df = pd.DataFrame(data)
# # else:
#     if uploaded_file.name.endswith('.csv'):
#         df = pd.read_csv(uploaded_file)
#     else:
#         df = pd.read_excel()

# # Preview Data
# st.subheader("Data Overview")
# st.dataframe(df.head(), use_container_width=True)

# # Create layout tabs for different analytical operations
# tab1, tab2, tab3 = st.tabs(["📊 Distribution", "📈 Relationships", "🍰 Composition"])

# # --- OPERATION 1: DISTRIBUTION (Bar Chart / Histogram) ---
# with tab1:
#     st.subheader("Numeric Distributions (e.g., Age, Scores, Attendance)")
#     numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    
#     if numeric_cols:
#         selected_num_col = st.selectbox("Select metric to view distribution:", numeric_cols, key="dist")
        
#         # Calculate frequency distribution using numpy
#         counts, bin_edges = np.histogram(df[selected_num_col].dropna(), bins=10)
#         hist_df = pd.DataFrame({
#             'Value Range': [f"{int(bin_edges[i])}-{int(bin_edges[i+1])}" for i in range(len(counts))],
#             'Student Count': counts
#         }).set_index('Value Range')
        
#         st.bar_chart(hist_df)
#     else:
#         st.error("No numeric columns found for distribution.")

# # --- OPERATION 2: RELATIONSHIP / CORRELATION (Scatter Plot) ---
# with tab2:
#     st.subheader("Analyze Trends Between Two Metrics")
#     if len(numeric_cols) >= 2:
#         col1, col2 = st.columns(2)
#         with col1:
#             x_axis = st.selectbox("X-Axis (Independent Variable):", numeric_cols, index=0)
#         with col2:
#             y_axis = st.selectbox("Y-Axis (Dependent Variable):", numeric_cols, index=min(1, len(numeric_cols)-1))
            
#         # Streamlit's native scatter plot maps numerical relations seamlessly
#         st.scatter_chart(df, x=x_axis, y=y_axis)
#     else:
#         st.error("You need at least two numeric columns to plot a relationship.")

# # --- OPERATION 3: COMPOSITION & CATEGORY COUNTS (Line/Area Chart Tracker) ---
# with tab3:
#     st.subheader("Categorical Trends Across the Dataset")
#     categorical_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
    
#     if categorical_cols:
#         selected_cat_col = st.selectbox("Select category to analyze:", categorical_cols, key="comp")
#         cat_counts = df[selected_cat_col].value_counts()
        
#         # Showing structural breakdown using an Area Chart alternative for comparison
#         st.write("Visualizing category volume representation:")
#         st.area_chart(cat_counts)
#     else:
#         st.error("No categorical columns found.")


import streamlit as st
import pandas as pd
import plotly.express as px
import seaborn as sns
import matplotlib.pyplot as plt

# Set page to wide mode for a dashboard layout
st.set_page_config(layout="wide")

# Load data (Replace with your actual file path)
@st.cache_data
def load_data():
    df = pd.read_csv("student_performance_dataset.csv")
    return df

df = load_data()
st.title("Student Performance Analytics Dashboard")

st.sidebar.header("Filter Options")

# Dropdown filters
grade = st.sidebar.multiselect("Select Grade Level:", options=df["grade_level"].unique(), default=df["grade_level"].unique())
gender = st.sidebar.multiselect("Select Gender:", options=df["gender"].unique(), default=df["gender"].unique())
study_group = st.sidebar.selectbox("Study Group Participation:", options=["All"] + list(df["study_group"].unique()))

# Apply filters to the dataframe
filtered_df = df[(df["grade_level"].isin(grade)) & (df["gender"].isin(gender))]
if study_group != "All":
    filtered_df = filtered_df[filtered_df["study_group"] == study_group]

# Calculate quick stats
total_students = len(filtered_df)
avg_math = filtered_df["math_score"].mean()
avg_science = filtered_df["science_score"].mean()
avg_english = filtered_df["english_score"].mean()
avg_attendance = filtered_df["attendance_percent"].mean()

# Display metrics in 4 columns
col1, col2, col3, col4 = st.columns(4)
col1.metric("Total Students", f"{total_students}")
col2.metric("Avg Attendance", f"{avg_attendance:.1f}%")
col3.metric("Avg Math Score", f"{avg_math:.1f}")
col4.metric("Avg Science / English", f"{avg_science:.1f} / {avg_english:.1f}")

tab1, tab2, tab3 = st.tabs(["Academic Overview", "Attendance & Factors", "Raw Data"])

with tab1:
    st.subheader("Score Distributions and Correlations")
    
    # Let users choose which score to view on a histogram
    score_col = st.selectbox("Select Subject for Distribution:", ["math_score", "science_score", "english_score"])
    fig_hist = px.histogram(filtered_df, x=score_col, color="gender", marginal="box", barmode="overlay")
    st.plotly_chart(fig_hist, use_container_width=True)

    # Create the pie chart using Plotly
    fig_pie = px.pie(filtered_df, names="study_group", 
    title="Students by Study Group Participation",
    hole=0.4 # Makes it a clean donut chart
    )

    # Display the chart in Streamlit
    st.plotly_chart(fig_pie, use_container_width=True)


with tab2:
    st.subheader("Impact Factors on Performance")
    
    # Scatter plot: Attendance vs Math Score
    fig_scatter = px.scatter(filtered_df, x="attendance_percent", y="math_score", color="extra_curricular", trendline="ols", title="Attendance vs. Math Performance")
    st.plotly_chart(fig_scatter, use_container_width=True)
    
    # Bar chart: Study Group Impact
    fig_bar = px.bar(filtered_df, x="study_group", y="science_score", color="gender", barmode="group", title="Study Group vs. Science Scores")
    st.plotly_chart(fig_bar, use_container_width=True)


    fig3, ax3 = plt.subplots(figsize=(6, 5))
    sns.boxplot(data=filtered_df, x="grade_level", y="science_score", hue="extra_curricular", ax=ax3)
    ax3.set_title("Science Performance by Grade Level")
    st.pyplot(fig3)

with tab3:
    st.subheader("Filtered Student Records")
    st.dataframe(filtered_df)
