# import streamlit as st
# import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn as sns

# # Page configurations
# st.set_page_config(page_title="Student Social Media Analytics", layout="wide")
# st.title("🎓 Student Social Media & Mental Health Dashboard")
# st.write("Analyze the behavioral impacts of social media usage on academic life.")

# # 1. Cached Data Loader
# @st.cache_data
# def load_student_data():
#     try:
#         # Update this filename to match your local CSV path
#         df = pd.read_csv("Students Social Media Addiction.csv")
#         # Clean column names just in case there are hidden white spaces
#         df.columns = df.columns.str.strip()
#         return df
#     except FileNotFoundError:
#         st.error("Student dataset file not found. Please verify the filename and path.")
#         return None

# df = load_student_data()

# if df is not None:
#     # --- SIDEBAR FILTERS ---
#     st.sidebar.header("🎯 Filter Options")
    
#     # Filter by Country
#     countries = ["All"] + list(df['Country'].unique())
#     selected_country = st.sidebar.selectbox("Select Country", countries)
    
#     # Filter by Academic Level
#     levels = ["All"] + list(df['Academic_Level'].unique())
#     selected_level = st.sidebar.selectbox("Select Academic Level", levels)
    
#     # Apply filters dynamically to the dataset
#     filtered_df = df.copy()
#     if selected_country != "All":
#         filtered_df = filtered_df[filtered_df['Country'] == selected_country]
#     if selected_level != "All":
#         filtered_df = filtered_df[filtered_df['Academic_Level'] == selected_level]

#     # --- MAIN KPI SCORECARDS ---
#     st.subheader("📊 Key Student Performance Indicators")
#     kpi1, kpi2, kpi3, kpi4 = st.columns(4)
    
#     with kpi1:
#         st.metric("Total Students Analyzed", len(filtered_df))
#     with kpi2:
#         avg_usage = filtered_df['Avg_Daily_Usage_Hours'].mean()
#         st.metric("Avg Daily Usage", f"{avg_usage:.1f} Hours")
#     with kpi3:
#         avg_sleep = filtered_df['Sleep_Hours_Per_Night'].mean()
#         st.metric("Avg Sleep/Night", f"{avg_sleep:.1f} Hours")
#     with kpi4:
#         avg_mental = filtered_df['Mental_Health_Score'].mean()
#         st.metric("Avg Mental Health Score", f"{avg_mental:.1f} / 100")

#     # --- INTERACTIVE VISUALIZATIONS ---
#     st.markdown("---")
#     col_left, col_right = st.columns(2)

#     with col_left:
#         st.subheader("📱 Most Used Platforms by Segment")
#         fig, ax = plt.subplots(figsize=(6, 4))
#         # Count platform popularity based on user demographic filters
#         sns.countplot(
#             data=filtered_df, 
#             y='Most_Used_Platform', 
#             order=filtered_df['Most_Used_Platform'].value_counts().index,
#             palette="viridis",
#             ax=ax
#         )
#         ax.set_xlabel("Number of Students")
#         ax.set_ylabel("")
#         st.pyplot(fig)

#     with col_right:
#         st.subheader("🧠 Addiction Score vs. Mental Health")
#         fig2, ax2 = plt.subplots(figsize=(6, 4))
#         # Scatter plot examining correlation, segmented by Relationship Status
#         sns.scatterplot(
#             data=filtered_df, 
#             x='Addicted_Score', 
#             y='Mental_Health_Score', 
#             hue='Gender',
#             alpha=0.7,
#             ax=ax2
#         )
#         ax2.set_xlabel("Addiction Score")
#         ax2.set_ylabel("Mental Health Score")
#         st.pyplot(fig2)

#     # --- ACADEMIC IMPACT DATA TABLES ---
#     st.markdown("---")
#     st.subheader("🏫 Academic Impact Breakdown")
    
#     # Pivot calculation to see if social media impacts performance scores
#     impact_summary = filtered_df.groupby('Affects_Academic_Performance').agg(
#         Avg_Daily_Usage=('Avg_Daily_Usage_Hours', 'mean'),
#         Avg_Sleep=('Sleep_Hours_Per_Night', 'mean'),
#         Avg_Addiction=('Addicted_Score', 'mean'),
#         Conflicts_Count=('Conflicts_Over_Social_Media', lambda x: (x == 'Yes').sum())
#     ).reset_index()
    
#     st.dataframe(impact_summary, use_container_width=True)
    
#     # Raw Data Preview Expansion Drawer
#     with st.expander("🔍 View Raw Filtered Dataset Rows"):
#         st.dataframe(filtered_df)

    
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Page configurations
st.set_page_config(page_title="Student Social Media Analytics", layout="wide")
st.title("🎓 Student Social Media & Mental Health Dashboard")
st.write("Analyze the behavioral impacts of social media usage on academic life.")

# 1. Cached Data Loader
@st.cache_data
def load_student_data():
    try:
        # Update this filename to match your local CSV path
        df = pd.read_csv("Students Social Media Addiction.csv")
        # Clean column names just in case there are hidden white spaces
        df.columns = df.columns.str.strip()
        return df
    except FileNotFoundError:
        st.error("Student dataset file not found. Please verify the filename and path.")
        return None

df = load_student_data()

if df is not None:
    # --- SIDEBAR FILTERS ---
    st.sidebar.header("🎯 Filter Options")
    
    # Filter by Country
    countries = ["All"] + list(df['Country'].unique())
    selected_country = st.sidebar.selectbox("Select Country", countries)
    
    # Filter by Academic Level
    levels = ["All"] + list(df['Academic_Level'].unique())
    selected_level = st.sidebar.selectbox("Select Academic Level", levels)
    
    # Apply filters dynamically to the dataset
    filtered_df = df.copy()
    if selected_country != "All":
        filtered_df = filtered_df[filtered_df['Country'] == selected_country]
    if selected_level != "All":
        filtered_df = filtered_df[filtered_df['Academic_Level'] == selected_level]

    # --- MAIN KPI SCORECARDS ---
    st.subheader("📊 Key Student Performance Indicators")
    kpi1, kpi2, kpi3, kpi4 = st.columns(4)
    
    with kpi1:
        st.metric("Total Students Analyzed", len(filtered_df))
    with kpi2:
        avg_usage = filtered_df['Avg_Daily_Usage_Hours'].mean()
        st.metric("Avg Daily Usage", f"{avg_usage:.1f} Hours")
    with kpi3:
        avg_sleep = filtered_df['Sleep_Hours_Per_Night'].mean()
        st.metric("Avg Sleep/Night", f"{avg_sleep:.1f} Hours")
    with kpi4:
        avg_mental = filtered_df['Mental_Health_Score'].mean()
        st.metric("Avg Mental Health Score", f"{avg_mental:.1f} / 100")

    # --- ROW 1 VISUALIZATIONS ---
    st.markdown("---")
    st.subheader("📱 Platform Popularity & Mental Health Correlates")
    col_left, col_right = st.columns(2)

    with col_left:
        st.markdown("**Most Used Platforms by Segment**")
        fig, ax = plt.subplots(figsize=(6, 3.5))
        sns.countplot(
            data=filtered_df, 
            y='Most_Used_Platform', 
            order=filtered_df['Most_Used_Platform'].value_counts().index,
            palette="viridis",
            ax=ax
        )
        ax.set_xlabel("Number of Students")
        ax.set_ylabel("")
        st.pyplot(fig)

    with col_right:
        st.markdown("**Addiction Score vs. Mental Health**")
        fig2, ax2 = plt.subplots(figsize=(6, 3.5))
        sns.scatterplot(
            data=filtered_df, 
            x='Addicted_Score', 
            y='Mental_Health_Score', 
            hue='Gender',
            alpha=0.7,
            ax=ax2
        )
        ax2.set_xlabel("Addiction Score")
        ax2.set_ylabel("Mental Health Score")
        st.pyplot(fig2)

    # --- NEW ROW 2 VISUALIZATIONS ---
    st.markdown("---")
    st.subheader("🌙 Sleep, Academic Stress & Relationship Conflicts")
    col_new1, col_new2, col_new3 = st.columns(3)

    with col_new1:
        st.markdown("**Usage vs. Sleep Tracking**")
        fig3, ax3 = plt.subplots(figsize=(5, 4))
        # Regression line plot to see if higher usage drops sleep hours
        sns.regplot(
            data=filtered_df,
            x='Avg_Daily_Usage_Hours',
            y='Sleep_Hours_Per_Night',
            scatter_kws={'alpha':0.4, 'color': '#3b82f6'},
            line_kws={'color': '#ef4444'},
            ax=ax3
        )
        ax3.set_xlabel("Daily Usage (Hours)")
        ax3.set_ylabel("Sleep Per Night (Hours)")
        st.pyplot(fig3)

    with col_new2:
        st.markdown("**Mental Health by Grade Tier**")
        fig4, ax4 = plt.subplots(figsize=(5, 4))
        # Box plot showing the distribution and outliers of mental health scores
        sns.boxplot(
            data=filtered_df,
            x='Academic_Level',
            y='Mental_Health_Score',
            palette="mako",
            ax=ax4
        )
        ax4.set_xlabel("Academic Level")
        ax4.set_ylabel("Mental Health Score")
        plt.xticks(rotation=15)
        st.pyplot(fig4)

    with col_new3:
        st.markdown("**Media Conflicts by Relationship Status**")
        fig5, ax5 = plt.subplots(figsize=(5, 4))
        # Grouped count plot to look at social media arguments across daters/singles
        sns.countplot(
            data=filtered_df,
            x='Relationship_Status',
            hue='Conflicts_Over_Social_Media',
            palette="pastel",
            ax=ax5
        )
        ax5.set_xlabel("Relationship Status")
        ax5.set_ylabel("Student Count")
        ax5.legend(title="Social Media Conflicts")
        plt.xticks(rotation=15)
        st.pyplot(fig5)

    # --- ACADEMIC IMPACT DATA TABLES ---
    st.markdown("---")
    st.subheader("🏫 Academic Impact Breakdown")
    
    # Pivot calculation to see if social media impacts performance scores
    impact_summary = filtered_df.groupby('Affects_Academic_Performance').agg(
        Avg_Daily_Usage=('Avg_Daily_Usage_Hours', 'mean'),
        Avg_Sleep=('Sleep_Hours_Per_Night', 'mean'),
        Avg_Addiction=('Addicted_Score', 'mean'),
        Conflicts_Count=('Conflicts_Over_Social_Media', lambda x: (x == 'Yes').sum())
    ).reset_index()
    
    st.dataframe(impact_summary, use_container_width=True)
    
    # Raw Data Preview Expansion Drawer
    with st.expander("🔍 View Raw Filtered Dataset Rows"):
        st.dataframe(filtered_df)
